
    
	<div class="footer_sec">
		<div class="container">
			<div class="row">
				<div class="col-md-2 col-6">
					<div class="list_group">
						<ul>
							<li><a href="">About</a></li>
							<li><a href="">Courses</a></li>
							<li><a href="">Accredited Courses</a></li>
							<li><a href="">Non-Accredited Courses</a></li>
	 					</ul>
					</div>
				</div>
	 			<div class="col-md-2 col-6">
						<div class="list_group">
							<ul>
								<li><a href="">Info</a>
								</li>
								<li><a href="">Student Handbook</a>
								</li>
								<li><a href="">Terms & Conditions</a>
								</li>
								<li><a href="">Privacy policy</a>
								</li>
							</ul>
						</div>
				</div>
									<div class="col-md-3 col-12">
										<div class="subs">
										<h1>Email Signup</h1>
											<div class="imput_sec">
												<input type="email" placeholder="Full Name*" name="EMAIL">
											</div>
											<div class="imput_sec">
												<input type="email" placeholder="Email Address*" name="EMAIL">
											</div> <a href="" class="btn">Subscribe</a>
										</div>
									</div>
				<div class="col-md-5 col-12">
					<div class="address_sec">
						<h1>Connect</h1>
						<div class="add_sec"> <a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
							<a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
							<a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
						</div>
						<ul class="address_footer">
							<li ><i class="fa fa-phone"></i><span>(02) 8884 2858</span></li>
							<li ><i class="fa fa-envelope"></i><span>enquiry@hinsw.com.au</span></li>
							<li><i class="fa fa-map-marker"></i><span>Hospitality Institute of NSW
								<br>17-19 Lexington Drive bella
								<br>Vista, NSW 2153</li></span>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
	
	
	
	<div class="copyright_sec">
		<div class="container">
			<div class="row">
				<div class="col-md-4">
					<div class="copy_txt">
						<p>© 2020-2021  www.hinsw.com</p>
					</div>
				</div>
	
				<div class="col-md-4">
					<div class="copy-mid">
						<p>RTO Number 45218   |   Security Master Licence Number: 000103878</p>
					</div>
				</div>
				<div class="col-md-4">
					<div class="copy_logo">
						<img src="{{ asset('images/logo.png') }}">
					</div>
				</div>
			</div>
		</div>
	</div>
